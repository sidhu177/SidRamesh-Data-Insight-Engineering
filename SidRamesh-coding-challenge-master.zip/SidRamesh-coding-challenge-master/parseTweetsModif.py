#!/usr/bin/env python

import sys
import json
import time

class Dictlist(dict):
    def __setitem__(self, key, value):
        try:
            self[key]
        except KeyError:
            super(Dictlist, self).__setitem__(key, [])
        self[key].append(value)
tweet_data = Dictlist()
dto_current = 0
i=0
j=0
created_at = ''
# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    #line = line.strip()
 json_input = line

 try:
  decoded = json.loads(json_input)  
  if 'created_at' in decoded :
     if 'entities' in decoded:
      hashtags = decoded['entities']['hashtags']        
      if hashtags :
       hashtag_texts = []
       for hashtag in hashtags:
         if 'text' in hashtag:
           hashtag_texts.append(str(hashtag['text']))
           #print hashtag['text']
       i = i+1
       if i == 1 :
          dto_current_init = time.mktime(time.strptime(str(decoded['created_at']),"%a %b %d %H:%M:%S +0000 %Y"))
       created_at = time.mktime(time.strptime(str(decoded['created_at']),"%a %b %d %H:%M:%S +0000 %Y"))
       time_diff = int(time.mktime(time.strptime(str(decoded['created_at']),"%a %b %d %H:%M:%S +0000 %Y")) - dto_current_init)
       tweet_data[created_at] = hashtag_texts
       #print tweet_data
       print '-------------------'
       p = 0
       initial_time = 0
       for i in sorted(tweet_data.keys(), reverse=True):
         if p==0:
            initial_time = int(i)
         else :
            break
         p = p+ 1
       degree = {}
       for i in sorted(tweet_data.keys(), reverse=True):
         time_diff = initial_time - int(i)
         #print initial_time
         #print int(i)
         if time_diff <= 60:
            print i, tweet_data[i]
            l = tweet_data[i]
            if len(l) > 1 :
                for item in l:
                    if item in degree.keys():
                        degree[item] = degree[item] + len(l) - 1
                    else :
                        degree[item] = len(l) - 1
            #print i, [item for sublist in l for item in sublist]
       total_degree = 0
       for deg in degree:
           total_degree = total_degree + degree[deg]
       denom = len(degree.keys())
       if denom !=0:
         print total_degree/len(degree.keys())
       print '-------------------'         
 except (ValueError, KeyError, TypeError):
   j = j+1

